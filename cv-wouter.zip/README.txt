A Pen created at CodePen.io. You can find this one at http://codepen.io/Wallycode/pen/Pmyzwx.

 Responsive resume template, you just need to fill out the content with your own. 